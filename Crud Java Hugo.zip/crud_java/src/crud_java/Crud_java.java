
package crud_java;


public class Crud_java {


    public static void main(String[] args) {

    }
    
}
